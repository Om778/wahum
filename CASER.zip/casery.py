##مطور السورس
caes = ["Z8ZZZ8Z"]
casery = "Z8ZZZ8Z"
##ايدي مطور السورس
caserid = 1095083160
##قناه السورس
source = "https://t.me/Z3ZZZZ3" 
ch = "Z3ZZZZ3" 
##جروب السورس
group = "https://t.me/PUBG6548" 
##لوجو السورس
photosource = "https://telegra.ph/%F0%9D%97%A6%F0%9D%97%A2%F0%9D%97%A8%F0%9D%97%A5%F0%9D%97%96%F0%9D%97%98-%F0%9D%97%AA%F0%9D%97%94%F0%9D%97%9B%F0%9D%97%A8%F0%9D%97%A0-09-01"
##توكن الصانع
bot_token="5055898511:AAGwE47ZJp6k6JfEq-YmYtBSxt0s7sm96pI"
##جلسه الاشتراك
bot_token2="BACr6jIAO2RhseP_OlYhNiPCCbzoVVl7NHFqFvIHhT_2fZ7B9FStCgTKYnmOvztjD4e5NQ1XIE8xN9GBHCRZ6qxYM-zxOqf8SriaTkgmFOzXJc9tXenzuc5Jaj_s3gHVTcyTr_7R_qM7nCVudb9nfQWrzMcBI0t4z0rmHCbcyZokeX-ZybA_abbMhx4pOiKmtdYI4c4GAvWt1WhejRGXcpipk578ifo9rcOaQusl32ToTiQRtN9UyZOnbajGUOQOlryzs-Y5Acon2j6MreWEV-8DckJYAnoppDoFJbW8_MFE76uhD4LhB24DhhiZAdqfr6s6qlHaFaoNqTBItSSEAmvgxd2vOAAAAAEq3hkPAA"